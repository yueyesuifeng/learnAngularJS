angular.module('hellosolarsystem').component('about', {
  template:  '<h3>Its the UI-Router<br>Hello Solar System app!</h3>'
})